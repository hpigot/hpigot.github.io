20180914
Harry Pigot

activity_drafts contains the latest versions of the Himalayan Makers Guild electronics and programming activities. They are still works in progress; they may have errors, missing parts, and include feedback comments from multiple sources.
